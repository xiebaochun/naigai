var State5 = Object.assign({}, BaseState, {
  init: function() {},
  preload: function() {},
  create: function() {

  }


})